<!-- Modal -->
<div class="modal fade" id="edit-category-<?= empty($category->id) ? 0 : $category->id; ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content border-raduis-lg">
            <div class="modal-header bg-light">
                <div class="modal-title text-dark">Edit category</div>
                <div class="cursor-pointer" data-dismiss="modal" aria-label="Close">
                    <i class="icofont-close text-danger"></i>
                </div>
            </div>
            <form method="POST" action="javascript:;" class="edit-category-form" data-action="<?= DOMAIN; ?>/categories/editCategory/<?= empty($category->id) ? 0 : $category->id; ?>">
                <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group input-group-lg col-md-6">
                            <label class="text-muted">Name</label>
                            <input type="text" name="name" class="form-control name" placeholder="e.g., Politics" value="<?= empty($category->name) ? "No Name" : $category->name; ?>">
                            <small class="error name-error text-danger"></small>
                        </div>
                        <div class="form-group input-group-lg col-md-6">
                            <label class="text-muted">Status</label>
                            <select class="custom-select form-control status" name="status">
                                <option value="">Select status</option>
                                <?php if(empty($categoryStatus)): ?>
                                    <option value="">No categories yet</option>
                                <?php else: ?>
                                    <?php foreach($categoryStatus as $status): ?>
                                        <option value="<?= $status; ?>" <?= ($category->status === $status) ? 'selected' : ''; ?>>
                                            <?= ucfirst($status); ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                            <small class="error status-error text-danger"></small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top-orange">
                    <div class="d-flex justify-content-left">
                        <button type="submit" class="btn bg-dark text-white btn-lg edit-category-button px-4">
                            <img src="<?= PUBLIC_URL; ?>/images/banners/spinner.svg" class="mr-2 d-none edit-category-spinner mb-1">
                            Save
                        </button>
                        <button type="button" class="btn bg-danger btn-lg text-white ml-3" data-dismiss="modal">
                            Close
                        </button>
                    </div>
                </div>
                <div class="px-3">
                    <div class="alert mt-2 mb-4 rounded edit-category-message d-none"></div>
                </div>
            </form>
        </div>
    </div>
</div>