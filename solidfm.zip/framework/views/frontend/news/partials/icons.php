<div class="qt-pushpin">
	<ul class="qt-sharepage qt-content-primary">
		<li class="hide-on-med-and-down">
			<i class="qticon-share qt-shareicon qt-content-primary-dark"></i>
		</li>
		<li>
			<a class="qt-popupwindow qt-sharelink" data-sharetype="facebook" data-name="Share" data-width="600" data-height="500" target="_blank" href="#">
				<i class="qticon-facebook"></i>
			</a>
		</li>
		<li>
			<a class="qt-popupwindow qt-sharelink" data-sharetype="twitter" data-name="Share" data-width="600" data-height="500" target="_blank" href="#">
				<i class="qticon-twitter"></i>
			</a>
			</li>
		<li>
			<a class="qt-popupwindow qt-sharelink" data-sharetype="google" data-name="Share" data-width="600" data-height="500" target="_blank" href="#">
				<i class="qticon-googleplus"></i>
			</a>
		</li>
		<li>
			<a class="qt-popupwindow qt-sharelink" data-sharetype="pinterest" data-name="Share" data-width="600" data-height="500" target="_blank" href="#">
				<i class="qticon-pinterest"></i>
			</a>
		</li>
		<li>
			<a href="#" class="qt-btn-primary qt-sharelink"><i class="dripicons-heart"></i>
			</a>
		</li>
	</ul>
</div>
<hr class="qt-spacer-m">