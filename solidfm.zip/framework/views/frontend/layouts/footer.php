<!-- QT FOOTER SCRIPTS ================================ -->
		<script src="<?= PUBLIC_URL; ?>/js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
		<script src="<?= PUBLIC_URL; ?>/js/jquery.js"></script><!--  JQUERY VERSION MUST MATCH WORDPRESS ACTUAL VERSION (NOW 1.12) -->
		<script src="<?= PUBLIC_URL; ?>/js/jquery-migrate.min.js"></script><!--  JQUERY VERSION MUST MATCH WORDPRESS ACTUAL VERSION (NOW 1.12) -->
	    
		<!-- Framework -->
		<script src="<?= PUBLIC_URL; ?>/js/materializecss/bin/materialize.min.js"></script>

		<!-- Cookies for player -->
		<script src="<?= PUBLIC_URL; ?>/js/jquerycookie.js"></script>

		 <!-- Slick carousel and skrollr -->
		<script src="<?= PUBLIC_URL; ?>/components/slick/slick.min.js"></script>
		<script src="<?= PUBLIC_URL; ?>/components/skrollr/skrollr.min.js"></script>
		
		<!-- Swipebox -->
		<script src="<?= PUBLIC_URL; ?>/components/swipebox/lib/ios-orientationchange-fix.js"></script>
		<script src="<?= PUBLIC_URL; ?>/components/swipebox/src/js/jquery.swipebox.min.js"></script>

		<!-- Countdown -->
		<script src="<?= PUBLIC_URL; ?>/components/countdown/js/jquery.knob.js"></script>
		<script src="<?= PUBLIC_URL; ?>/components/countdown/js/jquery.throttle.js"></script>
		<script src="<?= PUBLIC_URL; ?>/components/countdown/js/jquery.classycountdown.min.js"></script>

		<!-- Soundmanager2 -->
		<!--[if IE]><script src="components/soundmanager/script/excanvas.js"></script><![endif]-->
		<script src="<?= PUBLIC_URL; ?>/components/soundmanager/script/berniecode-animator.js"></script>
		<script src="<?= PUBLIC_URL; ?>/components/soundmanager/script/soundmanager2-nodebug.js"></script>
		<script src="<?= PUBLIC_URL; ?>/components/soundmanager/script/shoutcast.js"></script>
		<script src="<?= PUBLIC_URL; ?>/components/soundmanager/templates/qtradio-player/script/qt-360player-volumecontroller.js"></script>
		<!-- Popup -->
		<script src="<?= PUBLIC_URL; ?>/components/popup/popup.js"></script>
		<!-- MAIN JAVASCRIPT FILE ================================ -->
		<script src="<?= PUBLIC_URL; ?>/js/qt-main.js"></script>
	</body>
</html>