<div>
	<div class="" style="text-align: center; padding-top: 50px;">
		<h1 style="font-weight: bolder; color: #000;">404</h1>
		<p>Page Not Found</p>
	</div>
</div>