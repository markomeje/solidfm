<?php

namespace Application\Core;
use Application\Core\Application;
use Application\Components\Query;
use Application\Exceptions\{Logger};

class Model extends Application {

	public function __construct() {}

}
